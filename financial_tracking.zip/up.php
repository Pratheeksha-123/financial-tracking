<?php
include "dbconfig.php":
$usn=S_GET['id'];
if(isset($_POST['sub']))
{
	$name=$_POST['name'];
		$usn=$_POST['usn'];
		$sq="update b2 set name='$name' where usn='$usn'";
		if(mysqli_query($conn,$sq))
		{
			echo '<script>alert("update Successful!!")</script>';
			header("Refresh:1:url=dis.php");
			
			
		}
		else{
			echo '<script>alert("failed to update!!")</script>';
			header("refresh:5:url=dis.php");
		}
		mysql_close($conn);
}
?>
<form action="#" method="post">
<table>
<tr>
        <td>NAME</td>
		<td><input type="text" name="usn"  value="<?php echo $usn ;?>" required></td>
		</tr>
	<tr>	
				<td><input type="submit" name="submit"  value="submit" ></td>
				<td><input type="reset"  value="clear" ></td>
				</tr>
				</form>
				