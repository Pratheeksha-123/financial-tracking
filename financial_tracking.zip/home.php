<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'> 
<style type="text/css">
*
{
	
    margin: 0;

    padding: 0;

    box-sizing: border-box;

}
	
.full-page

{

    height: 100vh;

    width: 100%;
	
	background-image:url("bg.jpg");
	
	background-repeat:no-repeat;
	
	background-size:cover;

    position: absolute;

}

.sub-page

{

    width: 1266px;

    height: 559px;

    position: absolute;

    left: 50px;

    top: 50px;

}

.navigation-bar

{

    display: flex;

    align-items: center;

    padding: 20px;

    padding-left: 80px;

    padding-right: 30px;

    padding-top: 50px;

}

.logo

{
    font-family: sans-serif;
	
    position: relative;

    margin-top: 10px;

}

.logo a

{

    text-decoration: none;

    color: purple;

    font-size: 50px;

}

nav

{

    flex: 1;

    position: fixed;

    right: 0;

}

nav ul 

{

    display: inline-block;

    list-style: none;

}

nav ul li

{

    display: inline-block;

    margin-right: 90px;

    margin-top: 17px;

}

nav ul li a

{

    text-decoration: none;

    font-size: 20px;

    color: purple;

    font-family: sans-serif;

}
	
.flex-container{
	width:200%;
	height:auto;
	text-align:center;
	display:flex;
	flex-direction:columns;
	padding:100px;
}
.flex-box{
	width:600px;
	height:100px;
	text-align:center;
	background: #fffdd0;
	color:black;
	font-size:35px;
	line height:200px;
	text-align:center;
	border-radius:30px;
	margin:20px;
	
}	



</style>
</head>
<body>
	
    <div class="full-page">
        <div class="sub-page">
            <div class="navigation-bar">
                <div class="logo">
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <a href='photography.html'>BIZZ MONEY</a>
                </div>
                <nav>
                    <ul id='MenuItems'>
                        <li><a href='home.php'>Home</a></li>
                     
                        <li><a href='about.php'>About</a></li>
                        <li><a href='contact.php'>Contact</a></li>
						
						<li><a href='profile.php'><i class="fa fa-user-circle" style='font-size:36px;color:purple'></i></a></li>
                    </ul>
					
                </nav>
            </div>
			<ul>
					<hr size="5px" width="1450px" color="fffdd0">
					</ul><br>
			
			<div class="flex-container">
		<div class="flex-box">
			<a href="ex.php">EXPENSE TRACKER </a>
		</div>
		
		<div class="flex-box">
			<a href="index.php">BUDGET MANAGEMENT </a>
		</div>
			
			