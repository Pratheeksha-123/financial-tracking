<!DOCTYPE html>
<html>
<head>
<meta name="viewpoint"  content="width=device-width, initial-scale=1">
<style>
body {
	margin: 0;
	font-family: Arial, Helvetica, sans-serif;
}

.topnav{
	overflow: hidden;
	background-color: #333;
}

.topnav a{
	float: left;
	color: #f2f2f2;
	text-align: center;
	padding: 14px 16px;
	text-decoration:none;
	font-size: 17px;
}

.topnav a:hover{
	background-color: #ddd;
	color: black;
}

.topnav a.active{
	background-color: #04AA6D;
	color: white;
}
</style>
</head>
<body>
<div class="topnav">
          <a class="active" href="#home">Home</a>
           <a href="about.php">About</a>
           <a href="contact.php">Contact</a>
            <a href="register.php">Register</a>
</div>
</div>
<div style="padding-left:16px">
<?php
include "dbconfig.php";
echo "<h1> Display list </h1>"; 
$sql="SELECT * FROM b2";
$result = mysql_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
	echo "<table border=1><tr><th>Name</th><th>USN</th><th>Action</th></th>";
	while($row = mysqli_fetch_assoc($result))
	{
		echo "<tr>
                <td>".row["name"]."</td>
				<td>".row["usn"]."</td>
				                         <td> <a href='del.php?=".$row['usn']."'>Delete</a>  </td>;
										 <td> <a href='up.php?id=".$row['usn']."'>Update</a>  </td>;
	<tr>";
	}	
echo "</table>";
}
else
{
	 echo "0 results";
}
?>
</div>
</body>
</html>