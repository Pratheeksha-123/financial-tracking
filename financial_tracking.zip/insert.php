<?php
include "dbconfig.php";
$username=$_POST['username'];
$emailid=$_POST['emailid'];
$password=$_POST['password'];
$sql="insert into register(username,emailid,password)values('$username','$emailid','$password')";
if(mysqli_query($conn,$sql))
{
	echo "insert success";
	echo '<script> alert("insert done") </script>';
	header('refresh:1,url=reg.html');
}
else{
	echo "failure";
}
mysqli_close($conn);
?>