<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'> 
</head>
<style>
*

{

    margin: 0;

    padding: 0;

    box-sizing: border-box;

}

.full-page

{

    height: 100vh;

    width: 100%;

	background-image:url("bg.jpg");
	
	background-repeat:no-repeat;
	
	background-size:cover;

    position: absolute;

}

.sub-page

{

    width: 1266px;

    height: 559px;

    position: absolute;

    left: 50px;

    top: 50px;

}

.navigation-bar

{

    display: flex;

    align-items: center;

    padding: 20px;

    padding-left: 80px;

    padding-right: 30px;

    padding-top: 50px;

}

.logo

{
    font-family: sans-serif;
	
    position: relative;

    margin-top: 10px;

}

.logo a

{

    text-decoration: none;

    color: purple;

    font-size: 50px;

}

nav

{

    flex: 1;

    position: fixed;

    right: 0;

}

nav ul 

{

    display: inline-block;

    list-style: none;

}

nav ul li

{

    display: inline-block;

    margin-right: 90px;

    margin-top: 17px;

}

nav ul li a

{

    text-decoration: none;

    font-size: 20px;

    color: purple;

    font-family: sans-serif;

}

#about-section {
	
	width:600px;
		height:600px;
  background-color: #fffdd0;
  text-align: center;
  padding: 10px;
  
}

#about-section h2 {
  color: #333;
  text-align: center;
  font-size: 50px;
 
}

#about-section p {
	color: #333;
  margin-bottom: 10px;
  text-align: center;
font-size: 20px;
 font-family:'Kaushan Script',cursive;
}

	
</style>

<body>
    <div class="full-page">
        <div class="sub-page">
            <div class="navigation-bar">
                <div class="logo">
				&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    <a href='photography.html'>BIZZ MONEY</a>
                </div>
                <nav>
                    <ul id='MenuItems'>
                        <li><a href='home.php'>Home</a></li>
                        
                        <li><a href='about.php'>About</a></li>
                        <li><a href='contact.php'>Contact</a></li>
						
						<li><a href='profile.php'><i class="fa fa-user-circle" style='font-size:36px;color:purple'></i></a></li>
                    </ul>
                </nav>
            </div>
			<ul>
					<hr size="5px" width="1450px" color="fffdd0">
					</ul><br>
			<section id="about-section"
			<center>
  <h2>About Us</h2>
  
  <p>
    This is a PHP Project entitled Budget and Expense Tracker System. This system is a web-based application that manages your personal/small business budget and expenses.
  </p>
  <br><p>
    With this, you can easily track the entries budget and expenses by category. The project is simple, has a pleasant user interface, and is easy to use.
  </p>
  <p>
 Expense Tracker is an everyday expense control application designed to track effortlessly and efficiently each day costs. This helps us to get rid of the need of paper responsibilities that systematically maintains information. 
  </p>
  <p>
  Budget Management System with Source Code is a PHP project that can let you compute your exact expense through the web app. The program was built using PHP, MySQLi, and Javascript. The program is very easy to use, the user can enter an amount and description in order to compute the total amount of expenses.
  </p>
</center></section>