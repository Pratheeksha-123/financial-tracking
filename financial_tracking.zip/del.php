<?php
include "dbconfig.php";
$usn=$_GET['usn'];
//echo $usn;
$sq="delete from b2 where usn='$usn'";
if(mysql_query($conn,$sq))
{
	echo '<script>alert("Deleted!!")</script>';
	header("Refresh:0; url=dis.php");
}
else
{
	echo '<script>alert("failed to delete!!")</script>';
	header("Refresh:5:  url=dis.php");
}
mysqli_close($conn);
?>
