<?php
include "dbconfig.php";
$username=$_POST['username'];
$password=$_POST['password'];
$sql="select * from register where password='$password'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)==1)
{
	echo "login successful";
	echo '<script> alert("login successful") </script>';
	header('refresh:0,url=home.php');
}
else
{
echo "invalid login";
echo '<script> alert("invalid login") </script>';
header('refresh:0,url=reg.html');
}
mysqli_close($conn);
?>

