<?php
include "dbconfig.php";
$username=$_POST['name'];
$emailid=$_POST['email'];
$password=$_POST['message'];
$sql="insert into feedback(name,email,message)values('$username','$emailid','$password')";
if(mysqli_query($conn,$sql))
{
	//echo "insert success";
	echo '<script> alert("insert done") </script>';
	header('refresh:1,url=contact.php');
}
else{
	echo "failure";
}
mysqli_close($conn);
?>